import UIKit

//Inferida
var numero = 3
var num_decimal = 3.5
var text = "Texto Inferido"
var bool = true

//Explicita
var num_ent: Int = 4
var num_decim: Float = 4.3
var txt: String = "Texto explicito"
var boolE: Bool = false

//String y numero entero
let stringText: String = "Texto asignado"
let numeroenter: Int = 20

//Array
var numeros = {1;2;3;4;5;6;7;8;9}
var diasSemana = {1; "Lunes"; 2; "Martes"; 3; "Miercoles"; 4; "Jueves"; 5; "Viernes"; 6; "Sabado"; 7; "Domingo" }


